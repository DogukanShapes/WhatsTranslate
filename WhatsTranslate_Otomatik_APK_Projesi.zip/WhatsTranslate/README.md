# WhatsTranslate — Android MVP kaynak kodu

## Ne yapar?
- Türkçe → İngilizce: WhatsApp sohbetinde özel klavyenin **ÇEVİR + GÖNDER** tuşu ile cihaz üzerinde çeviri; WhatsApp `IME_ACTION_SEND` eylemini kabul ederse gönderim.
- İngilizce → Türkçe: erişilebilirlik servisi, seçilen sohbetteki **son görünen metni** cihaz üzerinde çevirip üst panelde gösterir. **Gelen mesajları doğru ayırt etme henüz tamamlanmadı**; son görünen metin bazen arayüz metni veya kendi mesajınız olabilir.
- Sohbet eşlemesi: ayarlara girilen sohbet başlığıyla ekranda görülen başlık eşleşmelidir. Bu yöntem WhatsApp sürümüne ve arayüzüne bağlıdır.

## Gereksinimler
Android Studio (JDK 17), Android SDK 35, Gradle/Android Gradle Plugin ve Google ML Kit bağımlılığını ilk kez indirmek için internet.

## Derleme
1. Android Studio > Open > `WhatsTranslate` klasörünü açın.
2. Gradle Sync tamamlanınca bir Android cihaza Run ile yükleyin veya Build > Build APK(s).
3. Uygulamayı açıp sohbet adını kaydedin, **Dil paketlerini indir** düğmesine basın (ilk seferde internet gerekir).
4. Klavyeyi etkinleştirin ve seçin. Gelen çeviriler için erişilebilirlik iznini ayrıca açın.
5. WhatsApp'ta kaydettiğiniz sohbeti açın; Türkçe yazın ve klavyedeki **ÇEVİR + GÖNDER** düğmesini kullanın.

## Sınırlamalar ve gizlilik
- **Bu prototip test edilmemiştir; derlenmesi ve farklı WhatsApp sürümlerinde çalışması doğrulanmamıştır.**
- WhatsApp'ın kendi gönder düğmesini değiştirmez. Özel klavye tuşu kullanılır.
- Mesajlar sunucuya gönderilmez. ML Kit dil modelleri **ilk kez internet üzerinden indirilir**, ardından çevrimdışı çalışır.
- Erişilebilirlik servisi WhatsApp ekranındaki metinlere erişir. Bu güçlü izni yalnızca güveniyorsanız verin.
- Kullanıcı adı eşlemesi kesin değildir; grup ve aynı isimli sohbetler için yeterli güvenlik sağlamaz.
- Otomatik gönderim `IME_ACTION_SEND` desteklenmezse metin çevrilir fakat kullanıcı WhatsApp'ta gönderir.
- Üretim kullanımı için sohbet tanıma, gelen/giden ayrımı, performans, hata yönetimi, veri gizliliği ve cihaz testleri gereklidir.
