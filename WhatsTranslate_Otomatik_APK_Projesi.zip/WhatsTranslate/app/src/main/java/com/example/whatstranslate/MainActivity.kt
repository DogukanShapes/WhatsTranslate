package com.example.whatstranslate

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.EditText
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(35, 55, 35, 30) }
        fun label(s: String) { root.addView(TextView(this).apply { text = s; textSize = 17f; setPadding(0, 10, 0, 12) }) }
        fun button(s: String, action: () -> Unit) { root.addView(Button(this).apply { text = s; setOnClickListener { action() } }) }
        label("WhatsTranslate • İlk sürüm\n\nÖnce dil paketlerini indir. Ardından klavyeyi etkinleştir ve seç. Gelen çeviriler için erişilebilirlik iznini aç.\n\nNot: Çeviri yalnızca seçtiğin sohbet başlığı eşleştiğinde etkinleşir.")
        val chat = EditText(this).apply { hint = "WhatsApp sohbet adı (tam eşleşme)"; setSingleLine(); setText(prefs.getString("chat", "")) }
        root.addView(chat)
        button("Sohbet adını kaydet") { prefs.edit().putString("chat", chat.text.toString().trim()).apply(); Toast.makeText(this, "Kaydedildi", Toast.LENGTH_SHORT).show() }
        button("Dil paketlerini indir (bir kez internet gerekir)") {
            TranslatorEngine.prepare({ Toast.makeText(this, "Dil paketleri hazır", Toast.LENGTH_LONG).show() }, { Toast.makeText(this, "İndirme hatası: ${it.message}", Toast.LENGTH_LONG).show() })
        }
        button("Klavyeyi etkinleştir") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        button("Klavyeyi seç") { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        button("Gelen mesaj çeviri iznini aç") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        label("Güvenlik: Gelen çeviriler WhatsApp'a yazılmaz; sadece ekran üstü küçük bir panelde görünür. Mesajlar bir sunucuya gönderilmez. Erişilebilirlik iznini dilediğin zaman kapatabilirsin.")
        setContentView(root)
    }
}
