package com.example.whatstranslate

import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.nl.translate.TranslateLanguage

/** Language packs must be downloaded once; translation thereafter runs on device. */
object TranslatorEngine {
    private val trEn by lazy {
        Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.TURKISH).setTargetLanguage(TranslateLanguage.ENGLISH).build())
    }
    private val enTr by lazy {
        Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.ENGLISH).setTargetLanguage(TranslateLanguage.TURKISH).build())
    }
    fun prepare(ok: () -> Unit, fail: (Exception) -> Unit) {
        trEn.downloadModelIfNeeded().addOnSuccessListener {
            enTr.downloadModelIfNeeded().addOnSuccessListener { ok() }.addOnFailureListener { fail(it) }
        }.addOnFailureListener { fail(it) }
    }
    fun outgoing(text: String, ok: (String) -> Unit, fail: (Exception) -> Unit) =
        trEn.translate(text).addOnSuccessListener(ok).addOnFailureListener(fail)
    fun incoming(text: String, ok: (String) -> Unit, fail: (Exception) -> Unit) =
        enTr.translate(text).addOnSuccessListener(ok).addOnFailureListener(fail)
}
