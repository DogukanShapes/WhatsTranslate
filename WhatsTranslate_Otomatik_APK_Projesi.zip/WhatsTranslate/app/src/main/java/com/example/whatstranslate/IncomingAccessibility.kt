package com.example.whatstranslate

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.graphics.Color
import android.os.Handler
import android.os.Looper

/** Experimental visible-message translation panel. Does not alter WhatsApp's UI. */
class IncomingAccessibility : AccessibilityService() {
    companion object { @Volatile var currentChat: String = "" }
    private var panel: TextView? = null
    private var lastText = ""
    private val handler = Handler(Looper.getMainLooper())
    private var pending: Runnable? = null
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName?.toString() !in listOf("com.whatsapp", "com.whatsapp.w4b")) { hide(); currentChat = ""; return }
        pending?.let { handler.removeCallbacks(it) }
        pending = Runnable { inspect() }.also { handler.postDelayed(it, 550) }
    }
    private fun inspect() {
        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 30 || texts.size > 200) return
            node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { texts.add(it) }
            for (i in 0 until node.childCount) walk(node.getChild(i), depth + 1)
        }
        walk(root, 0)
        val chosen = getSharedPreferences("settings", MODE_PRIVATE).getString("chat", "")?.trim().orEmpty()
        // Heuristic: chat title is generally visible near top; do not claim reliable contact detection.
        currentChat = if (chosen.isNotEmpty() && texts.take(12).contains(chosen)) chosen else ""
        if (currentChat.isEmpty()) { hide(); return }
        // MVP: translate last visible long-enough text; sender classification is not reliable yet.
        val candidate = texts.asReversed().firstOrNull { it.length >= 8 && it != chosen && it != lastText && it.any { c -> c.isLetter() } } ?: return
        lastText = candidate
        TranslatorEngine.incoming(candidate, { translated -> if (currentChat == chosen) show("Çeviri (son görünen metin): $translated") }, { /* Model unavailable: show nothing */ })
    }
    private fun show(message: String) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (panel == null) {
            panel = TextView(this).apply { setBackgroundColor(Color.rgb(31, 54, 42)); setTextColor(Color.WHITE); setPadding(20, 12, 20, 12); textSize = 14f; maxLines = 4 }
            val params = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP }
            wm.addView(panel, params)
        }
        panel?.text = message
    }
    private fun hide() {
        panel?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {} }
        panel = null
    }
    override fun onInterrupt() { hide() }
    override fun onDestroy() { pending?.let { handler.removeCallbacks(it) }; hide(); currentChat = ""; super.onDestroy() }
}
