package com.example.whatstranslate

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Minimal proof-of-concept keyboard: uses a text field's existing input connection. */
class TranslateKeyboard : InputMethodService() {
    private var busy = false
    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(8, 8, 8, 8) }
        root.addView(TextView(this).apply { text = "WhatsTranslate • Türkçe yaz, ardından ÇEVİR + GÖNDER"; textSize = 15f })
        val rows = listOf("qwertyuıopğü", "asdfghjklşi", "zxcvbnmöç")
        for (letters in rows) {
            val row = LinearLayout(this)
            for (letter in letters) {
                row.addView(Button(this).apply { text = letter.toString(); textSize = 12f; setPadding(0,0,0,0); layoutParams = LinearLayout.LayoutParams(0, 52.dp(), 1f)
                    setOnClickListener { currentInputConnection?.commitText(letter.toString(), 1) }
                })
            }
            root.addView(row)
        }
        val controls = LinearLayout(this)
        fun key(title: String, weight: Float = 1f, onClick: () -> Unit) {
            controls.addView(Button(this).apply { text = title; textSize = 12f; layoutParams = LinearLayout.LayoutParams(0, 58.dp(), weight); setOnClickListener { onClick() } })
        }
        key("⌫") { currentInputConnection?.deleteSurroundingText(1, 0) }
        key("Boşluk", 2f) { currentInputConnection?.commitText(" ", 1) }
        key(".") { currentInputConnection?.commitText(".", 1) }
        key("ÇEVİR + GÖNDER", 2.5f) { translateAndSend() }
        root.addView(controls)
        return root
    }
    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()
    private fun translateAndSend() {
        if (busy) return
        if (currentInputEditorInfo?.packageName !in listOf("com.whatsapp", "com.whatsapp.w4b")) {
            Toast.makeText(this, "Yalnızca WhatsApp içinde çalışır", Toast.LENGTH_SHORT).show(); return
        }
        val prefs = getSharedPreferences("settings", MODE_PRIVATE)
        val selected = prefs.getString("chat", "")?.trim().orEmpty()
        if (selected.isEmpty() || IncomingAccessibility.currentChat != selected) {
            Toast.makeText(this, "Seçili WhatsApp sohbeti algılanmadı", Toast.LENGTH_SHORT).show(); return
        }
        val connection = currentInputConnection ?: return
        val original = connection.getTextBeforeCursor(10000, 0)?.toString()?.trim().orEmpty()
        if (original.isEmpty()) return
        busy = true
        TranslatorEngine.outgoing(original, { english ->
            val current = currentInputConnection
            // Do not send if the user changed the text while translation was running.
            if (current != null && current.getTextBeforeCursor(10000, 0)?.toString()?.trim() == original) {
                current.beginBatchEdit()
                current.deleteSurroundingText(original.length, 0)
                current.commitText(english, 1)
                current.endBatchEdit()
                val sent = current.performEditorAction(EditorInfo.IME_ACTION_SEND)
                if (!sent) Toast.makeText(this, "Çevrildi. WhatsApp gönder tuşuna bas.", Toast.LENGTH_LONG).show()
            }
            busy = false
        }, { error ->
            busy = false
            Toast.makeText(this, "Çeviri yapılamadı; mesaj gönderilmedi: ${error.message}", Toast.LENGTH_LONG).show()
        })
    }
}
